<?php
class AjaxHelpers
{

}