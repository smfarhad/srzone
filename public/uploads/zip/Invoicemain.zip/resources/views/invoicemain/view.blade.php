@extends('layouts.app')

@section('content')
<div class="page-content row">
    <!-- Page header -->
    <div class="page-header">
      <div class="page-title">
        <h3> {{ $pageTitle }} <small>{{ $pageNote }}</small></h3>
      </div>
      <ul class="breadcrumb">
        <li><a href="{{ URL::to('dashboard') }}">{{ Lang::get('core.home') }}</a></li>
		<li><a href="{{ URL::to('invoicemain?return='.$return) }}">{{ $pageTitle }}</a></li>
        <li class="active"> {{ Lang::get('core.detail') }} </li>
      </ul>
	 </div>  
	 
	 
 	<div class="page-content-wrapper m-t">   

<div class="sbox animated fadeInRight">
	<div class="sbox-title"> 
   		<a href="{{ URL::to('invoicemain?return='.$return) }}" class="tips btn btn-xs btn-default pull-right" title="{{ Lang::get('core.btn_back') }}"><i class="fa fa-arrow-circle-left"></i>&nbsp;{{ Lang::get('core.btn_back') }}</a>
		@if($access['is_add'] ==1)
   		<a href="{{ URL::to('invoicemain/update/'.$id.'?return='.$return) }}" class="tips btn btn-xs btn-primary pull-right" title="{{ Lang::get('core.btn_edit') }}"><i class="fa fa-edit"></i>&nbsp;{{ Lang::get('core.btn_edit') }}</a>
		@endif 
	</div>
   <div class="panel-body">
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Invoice No : </label>
                        <p>#{{ $row->invoiceid }}</p>
                    </div>
                    <div class="form-group">
                        <label>Grand Total</label>
                        <p>{{ $row->amount }}  TAKA </p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Customer Name : </label>
                        <p>{!! SiteHelpers::gridDisplayView($row->customerid,'customerid','1:customer:CustomerId:FullName') !!}</p>
                    </div>
                    <div class="form-group">
                        <label>Customer Address : </label>
                        <pre class="pre">{{ $row->CustomerAddress }}</pre>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Status</label>
                        <p> {{ $row->status_id }} </p>
						

                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <label>Invoice Date</label>
                            <p> {{ $row->invoicedate }} </p>
                        </div>
                        <div class="col-sm-6">
                            <label>Due Date</label>
                            <p>{{ $row->duadate }}</p>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Connection Fee</th>
                        <th></th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                   
                        <tr>
                            <td class="table-name"> Monthly Line Bill </td>
                            <td class="table-price">{{ $row->amount }} TAKA</td>
                            <td class="table-qty"> </td>
                            <td class="table-total text-right">{{ $row->amount }}TAKA</td>
                        </tr>
                  
                </tbody>
                <tfoot>
                    <tr>
                        <td class="table-empty" colspan="2"></td>
                        <td class="table-label">Sub Total</td>
                        <td class="table-amount">{{ $row->amount }}</td>
                    </tr>
                    
                    <tr>
                        <td class="table-empty" colspan="2"></td>
                        <td class="table-label">Grand Total</td>
                        <td class="table-amount">{{ $row->amount }}</td>
                    </tr>
                </tfoot>
            </table>
</div>	
@if($access['is_edit'] ==1)
						<a  href="{{ URL::to('invoicemain/update/'.$row->invoiceid.'?return='.$return) }}" class="tips btn btn-lg btn-success" title="PAY NOW">PAY NOW</a>
						@endif
	</div>
</div>
	  
@stop